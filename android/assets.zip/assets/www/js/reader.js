var bookshelf = [];
var books[];
var booksPath = "";
var workPath = "";
var currentBook = null;
var navLinks = [];
var navStructure = {};

function getBookList(){	
	books = [];
	return books;
}

function searchBooks(){
	//default location;	
}

function addNewBook(bookName){	
	unpack_path  = createNewBookFolder(bookName); 
	unpackBook(bookName, unpack_path);	
}
function createNewBookFolder(bookName){
	return workPath + "/" + bookName;
}

// descompacta o livro em uma pasta
function unpackBook(bookName, unpack_path){
	var bookSource = booksPath + "/" + bookName;

}

function runBook(book_id){
	
}